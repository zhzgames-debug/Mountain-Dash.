# Mountain Dash — Android

Android-only wrapper for **Mountain Dash: Gilgit Adventure**.

## One-click APK build
1. Create a GitHub repository.
2. Upload this project and push to `main`.
3. Open **Actions** → **Build Mountain Dash APK** → **Run workflow**.
4. Download the `mountain-dash-debug-apk` artifact.

The project uses JDK 17 and builds with the Android Gradle Plugin through GitHub Actions. No WhatsApp/contact number is included.

## Stability focus
- Single requestAnimationFrame loop in the game.
- Delta time capped to prevent physics jumps after backgrounding.
- Canvas rendering with capped device pixel ratio.
- Reused in-memory game arrays; no per-frame DOM creation.
- WebView hardware acceleration enabled.
- WebView paused/resumed with Android lifecycle.
- Portrait orientation and immersive full-screen gameplay.
